JIYA ELECTRONICS & SOLAR — PROFESSIONAL FIRST VERSION

Copy the complete contents into:
D:\Jiya electrical and solar\jiya-website

Then open index.html with Live Server.

Brand list:
1. Luminous 2. Exide 3. Intu 4. Eastman 5. Amaron
6. Livguard 7. Microtek 8. UTL 9. Massimo 10. Livfast

Phone/WhatsApp: 98420 93234
Service areas: Kottaipattinam, Manamelkudi, Aranthangi, Pudukkottai
